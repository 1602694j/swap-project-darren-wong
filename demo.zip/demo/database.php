<?php
	$dbhost = "localhost";
	$dbname = "demo";
	$dbuser = "root";
	$dbpassword = "";
	$dbconn = mysqli_connect ($dbhost, $dbuser, $dbpassword) or die (mysqli_error ()); 
	mysqli_select_db ($dbconn,$dbname);
?>

