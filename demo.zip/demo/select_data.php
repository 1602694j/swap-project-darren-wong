<html>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$employeeID = mysqli_real_escape_string($conn, $_REQUEST['employeeID']);
$sql = "SELECT employeeID, name, role, email, contact, address, salary, joindate FROM employees WHERE employeeID='$employeeID'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
echo "<table align='center' border='1'>";
echo "<tr>";
echo "<th>Employee ID</th>";
echo "<th>Name</th>";
echo "<th>Role</th>";
echo "<th>Email</th>";
echo "<th>Contact</th>";
echo "<th>Address</th>";
echo "<th>Salary</th>";
echo "<th>Join Date</th>";
echo "</tr>";
    while($row = $result->fetch_assoc()) {
  
  echo "<tr>";
  echo "<td>".$row["employeeID"]."</td>";
  echo "<td>".$row["name"]."</td>";
  echo "<td>".$row["role"]."</td>";
  echo "<td>".$row["email"]."</td>";
  echo "<td>".$row["contact"]."</td>";
  echo "<td>".$row["address"]."</td>";
  echo "<td>".$row["salary"]."</td>";
  echo "<td>".$row["joindate"]."</td>";
  echo "</tr>"; 
  echo "</table>";
    }
} else {
    echo "No employee found with that ID";
}
$conn->close();
?>
<a href="index.php"><input type="button" value="Back" style="padding-center; background-color:peach "/>
</body>
</html>