<html>
	<center>
	<body>
	<title>Employees</title>
	<h1>Employees</h1>
<?php 
	require_once ('database.php'); 

	$sql = "SELECT * FROM employees ORDER BY employeeID";
	$result = mysqli_query ($dbconn, $sql);

echo "<table border='1' >
<tr>
<td align=center><b>Employee ID</b></td>
<td align=center><b>Name</b></td>
<td align=center><b>Role</b></td>
<td align=center><b>Email Name</b></td>
<td align=center><b>Contact</b></td>
<td align=center><b>Address</b></td>
<td align=center><b>Salary</b></td>
<td align=center><b>Join Date</b></td>";

while($data = mysqli_fetch_row($result))
{   
    echo "<tr>";
    echo "<td align=center>$data[0]</td>";
    echo "<td align=center>$data[1]</td>";
    echo "<td align=center>$data[2]</td>";
    echo "<td align=center>$data[3]</td>";
    echo "<td align=center>$data[4]</td>";
	echo "<td align=center>$data[5]</td>";
	echo "<td align=center>$data[6]</td>";
	echo "<td align=center>$data[7]</td>";
    echo "</tr>";
}

echo "</table>";
?>

	<a href="inserthtml.html"><input type="button"  value="Insert" style="padding-left:50px; background-color:peach "/>
	<a href="selecthtml.html"><input type="button" value="Select" style="padding-left:50px; background-color:peach "/>
	<a href="updatehtml.html"><input type="button" value="Update" style="padding-left:50px; background-color:peach "/>
	<a href="deletehtml.html"><input type="button" value="Delete" style="padding-left:50px; background-color:peach "/>
	</body>
	</center>
</html>