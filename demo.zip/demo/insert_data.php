<html>
<body>
<?php

$link = mysqli_connect("localhost", "root", "", "demo");
 

if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
$employeeID = mysqli_real_escape_string($link, $_REQUEST['employeeID']);
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$role = mysqli_real_escape_string($link, $_REQUEST['role']);
$email = mysqli_real_escape_string($link, $_REQUEST['email']);
$contact = mysqli_real_escape_string($link, $_REQUEST['contact']);
$address = mysqli_real_escape_string($link, $_REQUEST['address']);
$salary = mysqli_real_escape_string($link, $_REQUEST['salary']);
$joindate = mysqli_real_escape_string($link, $_REQUEST['joindate']);


$sql = "INSERT INTO employees(employeeID, name, role, email, contact, address, salary, joindate) VALUES ('$employeeID', '$name', '$role', '$email', '$contact', '$address', '$salary','$joindate')";
if(mysqli_query($link, $sql)){
    echo "Insert new employee succesfully.";
} else{
    echo "Unabled to insert new employee. Employee ID most likely taken. " . mysqli_error($link);
}
 
mysqli_close($link);
?>
<a href="index.php"><input type="button" value="Back" style="padding-center; background-color:peach "/>
</body>
</html>