<html>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$employeeID=mysqli_real_escape_string($conn, $_REQUEST['employeeID']);
$name=mysqli_real_escape_string($conn, $_REQUEST['name']);
$role=mysqli_real_escape_string($conn, $_REQUEST['role']);
$email=mysqli_real_escape_string($conn, $_REQUEST['email']);
$contact=mysqli_real_escape_string($conn, $_REQUEST['contact']);
$address=mysqli_real_escape_string($conn, $_REQUEST['address']);
$salary=mysqli_real_escape_string($conn, $_REQUEST['salary']);
$sql = "UPDATE employees SET name='$name', role='$role', email='$email', contact='$contact', address='$address', salary='$salary'  WHERE employeeID='$employeeID'";

if (mysqli_query($conn, $sql)) {
    echo "Employee updated successfully";
} else {
    echo "Error updating employee... " . mysqli_error($conn);
}

mysqli_close($conn);
?>
<a href="index.php"><input type="button" value="Back" style="padding-center; background-color:peach "/>
</body>
</html>