<html>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "demo";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$employeeID = mysqli_real_escape_string($conn, $_REQUEST['employeeID']);

$sql = "DELETE FROM employees WHERE employeeID=$employeeID";

if (mysqli_query($conn, $sql)) {
    echo "Record has been deleted successfully! Please click back to view the table";
} else {
    echo "Error deleting record...: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
<a href="index.php"><input type="button" value="Back" style="padding-center; background-color:peach "/>
</body>
</html>